// 10. Write a program that calculates the sum of two numbers and prints the result.


public class Task10{
    public static void main(String[] args){
        int a=10;
        int b=15;
        int sum=a+b;
        System.out.println("The Sum of "+a+" and "+b+" is "+sum+".");
    }
}