// 1. Print out "Hello, world!" to the console.

public class Task1{
    public static void main(String[] args){
        System.out.println("Hello, world!");
    }
}